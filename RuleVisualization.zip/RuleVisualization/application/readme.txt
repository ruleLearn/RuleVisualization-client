RuleVisualization 1.0
------------------------------------------------
1. Run server file or by running batch script ./run-server.bat or by running:
   java -jar server/server.jar <port>
   Default port: 8081 if not specified.
2. Run client by running client/index.html file or by running shortcut ./run-client.