module.exports = {
	devServer: {
		host: 'localhost',
		port:8080
	},
	lintOnSave: false,
	publicPath: '',
};